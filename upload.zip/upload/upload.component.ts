import { HttpClient, HttpRequest, HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MyApp } from 'app/init';
import { NzMessageService, UploadFile } from 'ng-zorro-antd';
import { Observable, Observer } from 'rxjs';
import { filter } from 'rxjs/operators';
import { UploadFileInfo, UploadService, UploadStatusEnum } from './upload.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent implements OnInit {

  constructor(public service: UploadService, private app: MyApp) { }

  @Input() uploadUrl: string;           //上传的url
  @Input() modelId: string;
  @Input() multiple: boolean = true;    // 是否支持多选文件，ie10+ 支持。开启后按住 ctrl 可选择多个文件。
  @Input() disabled?: boolean = false;   // 是否禁用
  @Input() limit?: number = 99;          // 限制单次最多上传数量，nzMultiple 打开时有效；0 表示不限

  ngOnInit() {
  }

  beforeUpload = (file: File) => {
    this.service.addFile(file, this.modelId)
    return false;
  }

  doRemove(item: UploadFileInfo) {
    item.remove = true;
    this.service.updateFileList(item);
  }

  handleUpload(event: Event) {
    event.stopPropagation()
    if (!this.service.state.validCount) {
      this.app.error('没有可以上传的文件');
      return;
    }
    if (this.service.state.invalidCount > 0) {
      this.app.confirm('存在不能上传的文件，是否继续？', '', data => {
        if (data) {
          this.service.setState('modelId', this.modelId);
          this.service.uploadFiles(this.uploadUrl);
        }
      });
    } else {
      this.service.setState('modelId', this.modelId);
      this.service.uploadFiles(this.uploadUrl);
    }
  }

}
