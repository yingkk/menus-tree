import { HttpClient, HttpRequest, HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AppDao } from '@finegold/api';
import { MyApp } from 'app/init';
import { NzMessageService, UploadFile } from 'ng-zorro-antd';
import { Observable, Observer } from 'rxjs';
import { distinctUntilChanged, filter, tap } from 'rxjs/operators';
import { UploadFileInfo, UploadService, UploadStatusEnum } from './upload.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent implements OnInit {

  constructor(public service: UploadService, private app: MyApp, private appDao: AppDao, private cdr: ChangeDetectorRef) { }

  @Input() uploadUrl: string;           //上传的url
  @Input() modelId: string;
  @Input() multiple: boolean = true;    // 是否支持多选文件，ie10+ 支持。开启后按住 ctrl 可选择多个文件。
  @Input() disabled?: boolean = false;   // 是否禁用
  @Input() limit?: number = 99;          // 限制单次最多上传数量，0 表示不限, nzMultiple 打开时有效；

  @Output() onUploadSuccess: EventEmitter<any> = new EventEmitter();

  sub$$: any;

  
  ngOnInit() {
    this.sub$$ = this.service.state$.pipe(
      distinctUntilChanged((x, y) => x.uploading === y.uploading),
      tap(state => {
        if (!state.uploading) {
          if (this.sub$$) {
            this.onUploadSuccess.emit();
          }
        }
      })
    ).subscribe();
  }

  beforeUpload = (file: File) => {
    this.service.addFile(file, this.modelId)
    return false;
  }

  handleRemove(item: UploadFileInfo) {
    item.remove = true;
    this.service.updateFileList(item);
  }

  handleClear(event: Event) {
    event.stopPropagation()
    this.service.clearFileList()
  }

  handleUpload() {
    if (!this.service.state.validCount) {
      this.app.error('没有可以上传的文件');
      return;
    }
    if (this.service.state.invalidCount > 0) {
      this.app.confirm('存在不能上传的文件，是否继续？', '', data => {
        if (data) {
          this.service.setState('modelId', this.modelId);
          this.service.uploadFiles(this.uploadUrl);
        }
      });
    } else {
      this.service.setState('modelId', this.modelId);
      this.service.uploadFiles(this.uploadUrl);
    }
  }

}
