import { Injectable } from '@angular/core';
import { ProgressInfo } from '@finegold/api';
import { BaseState, StateService } from '@finegold/app';
import { GUID } from '@finegold/utils';
import { MyApp } from 'app/init';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UploadService extends StateService<UploadState> {

  constructor(public appService: MyApp) {
    super(initialState);
  }

  private abort?: () => void;

  fileAbort(fi: UploadFileInfo) {
    if (fi.status === UploadStatusEnum.uploading && this.abort) {
      this.abort();
      this.abort = null;
    }
  }

  private getSizeText(size: number) {
    if (size < 1024) {
      return size + " B";
    } else if (size < 1024 * 1024) {
      return (size / 1024).toFixed(2) + " KB";
    } else if (size < 1024 * 1024 * 1024) {
      return (size / 1024 / 1024).toFixed(2) + " MB";
    } else if (size < 1024 * 1024 * 1024 * 1024) {
      return (size / 1024 / 1024 / 1024).toFixed(2) + " GB";
    } else if (size > 1024 * 1024 * 1024 * 1024) {
      return (size / 1024 / 1024 / 1024).toFixed(2) + " GB";
    }
  }

  clearFileList() {
    this.updateState('fileList', []);
    this.commitState();
  }

  addFile(file: File, modelId: string) {
    let _file: UploadFileInfo = {
      uid: GUID.newGUID(),
      size: file.size,
      sizeText: this.getSizeText(file.size),
      name: file.name,
      type: file.type,
      file: file,
      status: UploadStatusEnum.checking,
      statusText: '正在校验',
      modelId: modelId
    }

    //TODO 验证file type

    let reg = new RegExp('[+/?%#&=]');
    if (reg.test(_file.name)) {
      _file.status = UploadStatusEnum.invalid;
      _file.statusText = '特殊字符';
    } else {
      _file.status = UploadStatusEnum.ready;
      _file.statusText = '待上传';
    }
    this.updateFileList(_file);
  }


  updateFileList(file: UploadFileInfo) {
    const _index = this.state.fileList.findIndex(t => t.uid === file.uid)
    _index > -1 ? this.state.fileList.splice(_index, 1, file) : this.state.fileList.push(file)
    this.updateState('fileList', [...this.state.fileList])
    this.commitState();
    this.updateFileCountByDiffStatus(this.state.fileList)
  }

  updateFileCountByDiffStatus(files: UploadFileInfo[]) {
    let validCount = files.filter(it => it.status == UploadStatusEnum.ready && !it.remove).length;
    let invalidCount = files.filter(it => it.status == UploadStatusEnum.invalid && !it.remove).length;
    let sucessCount = files.filter(it => it.status == UploadStatusEnum.done && !it.remove).length;
    let errorCount = files.filter(it => it.status == UploadStatusEnum.error && !it.remove).length;
    let uploadingCount = files.filter(it => it.status == UploadStatusEnum.uploading && !it.remove).length;
    let data = {
      validCount: validCount,
      invalidCount: invalidCount,
      sucessCount: sucessCount,
      failCount: errorCount,
      uploadingCount: uploadingCount,
    };
    this.setStates({ ...this.state, ...data } as any);
    this.commitState();
  }

  uploadFiles(url: string) {
    this.updateState('uploading', true);
    let doOne = () => {
      let fi = this.state.fileList.find(it => it.status == UploadStatusEnum.ready && !it.remove);
      if (fi) {
        fi.remove = false;
        this.uploadFile(url, fi).subscribe(pi => {
          if (pi.done) {
            doOne();
          }
        }, err => {
          this.updateState('uploading', false);
          this.commitState();
          fi = {
            ...fi,
            percent: err['progress'],
            status: UploadStatusEnum.error,
            statusText: err.error === '取消上传' ? '取消上传' : '上传失败'
          };
          this.updateFileList(fi);
          throw new Error(err.error);
        }, () => {
        });
      } else {
        this.updateState('uploading', false);
        this.commitState();
      }
    };
    doOne();
  }

  private uploadFile(url: string, file: UploadFileInfo) {
    let params = { uid: file.uid }
    return this.ajaxUpload(url, file.file, params).pipe(
      tap((progressInfo: DefineProgressInfo) => {
        file = {
          ...file,
          percent: progressInfo.progress,
          status: progressInfo.done ? UploadStatusEnum.done : (progressInfo.loaded == progressInfo.total ? UploadStatusEnum.handle : UploadStatusEnum.uploading),
          statusText: progressInfo.done
            ? '上传完成'
            : (progressInfo.loaded == progressInfo.total
              ? '正在处理'
              : '正在上传')
        };
        this.abort = progressInfo.abort;
        this.updateFileList(file);
      })
    );
  }

  ajaxUpload(url: string, file: File, params?: { [prop: string]: any }): Observable<DefineProgressInfo> {
    url = this.appService.appRest.getUrl(url);
    const form = new FormData();
    form.append('file', file, file.name);
    if (params) {
      for (const prop in params) {
        form.append(prop, params[prop]);
      }
    }
    return new Observable(obserer => {
      const xhr = new XMLHttpRequest();
      xhr.withCredentials = true;
      xhr.open('POST', url, true);
      xhr.responseType = 'json';  // 返回类型blob

      let doNext = (pi: ProgressInfo) => {
        let ppi = {
          ...pi, abort: () => {
            xhr.abort();
            obserer.error({ ...pi, error: '取消上传' });
          }
        };
        obserer.next(ppi);
      };

      xhr.onloadstart = (ev) => {
        doNext({ total: ev.total, loaded: 0, progress: 0, done: false });
      };

      if (xhr.upload) {
        xhr.upload.addEventListener('progress', (ev: any) => {
          doNext({
            total: ev.total, loaded: ev.loaded,
            progress: Math.round(100 * ev.loaded / ev.total), done: false
          });
        });
      }

      xhr.onprogress = (ev) => {
        doNext({
          total: ev.total, loaded: ev.loaded,
          progress: Math.round(100 * ev.loaded / ev.total), done: false
        });
      };
      xhr.onerror = function (ev) {
        doNext({
          total: ev.total, loaded: ev.loaded, done: false,
          error: this.statusText
        });
        obserer.error(ev);
      };
      // 定义请求完成的处理函数
      xhr.onload = function (ev) {
        // 请求完成
        if (this.status === 200) {
          // 返回200
          const blob = this.response;
          doNext({ total: ev.total, progress: 100, loaded: ev.loaded, done: true, blob });
          obserer.complete();
        } else {
          console.log('error...' + this.status + '/' + this.statusText);
          doNext({ total: ev.total, progress: Math.round(100 * ev.loaded / ev.total), loaded: ev.loaded, error: this.statusText });
        }
      };
      // 发送ajax请求
      xhr.send(form);
    });

  }
}

export interface UploadState extends BaseState {
  onlyOneFile: boolean;
  fileList?: UploadFileInfo[];
  uploading?: boolean;
  validCount?: number;
  invalidCount?: number;
  sucessCount?: number;
  uploadingCount?: number;
  failCount?: number;
  modelId?: string;
}

const initialState = {
  onlyOneFile: false,
  fileList: [],
  uploading: false,
  validCount: 0,
  invalidCount: 0,
  sucessCount: 0,
  uploadingCount: 0,
  failCount: 0,
  modelId: null,
};

export enum UploadStatusEnum {
  // checking,
  // invalid,
  // ready,
  // error,
  // success,
  // done,
  // uploading,
  // removed,  //  最新增加处理中
  checking,
  invalid,
  ready,
  uploading,
  done,
  error,
  handle,  //  最新增加处理中
}

export interface UploadFileInfo {
  uid: string;
  size: number;
  sizeText?: string;
  type: string;
  name: string;
  file?: File;
  status?: UploadStatusEnum;
  statusText?: string;
  percent?: number;
  error?: any;
  remove?: boolean;     // 移除标识
  modelId?: string;
}

export interface DefineProgressInfo extends ProgressInfo {
  abort?: () => void;
}
